<?php
return array(
    'id' =>             'recaptcha',
    'version' =>        '0.1',
    'name' =>           'Recaptchav3',
    'author' =>         'Raul Orellana',
    'description' =>    'Provides google recaptcha v3 as a form field type to avoid spam',
    'plugin' =>         'recaptcha.php:GoogleRecaptchaV3',
);
