<?php
require_once INCLUDE_DIR . 'class.plugin.php';

class GoogleRecaptchaV3Config extends PluginConfig{
    function getOptions() {       
        return array(
            'google' => new SectionBreakField(array(
                'label' => 'Google reCAPTCHA Verification',
            )),
            'g-site-key' => new TextboxField(array(
                'label' => 'Site Key',
                'required'=> true,
                'configuration' => array('size'=>60, 'length'=>100, 'autocomplete'=>'off'),
            )),
            'g-secret-key' => new TextboxField(array(
                'widget'=>'PasswordWidget',
                'required'=>true,
                'label' => 'Secret Key',
                'configuration' => array('size'=>60, 'length'=>100),
            ))
        );
    }

    function pre_save(&$config, &$errors) {
        // Todo: verify key
        if (!function_exists('curl_init')) {
            Messages::error('CURL extension is required');
            return false;
        }
        global $msg;
        if (!$errors) {
            // Add your reCAPTCHA v3 validation here
            $recaptcha_response = $_POST['g-recaptcha-response']; // Assuming your form has this field
            $secret_key = $config['g-secret-key']; // Get secret key from config
            $verify_url = 'https://www.google.com/recaptcha/api/siteverify';
            $data = array(
                'secret' => $secret_key,
                'response' => $recaptcha_response
            );

            $options = array(
                'http' => array(
                    'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                    'method' => 'POST',
                    'content' => http_build_query($data)
                )
            );

            $context = stream_context_create($options);
            $result = file_get_contents($verify_url, false, $context);
            $result_json = json_decode($result, true);

            if ($result_json['success']) {
                $msg = 'Successfully updated reCAPTCHA settings';
                return true;
            } else {
                Messages::error('reCAPTCHA verification failed');
                return false;
            }
        }
    }
}
?>
